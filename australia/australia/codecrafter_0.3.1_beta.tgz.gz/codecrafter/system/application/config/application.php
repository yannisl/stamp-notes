<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
| ------------------------------------------------------------------------------
| APPLICATION SPECIFIC CONFIG VALUES
| ------------------------------------------------------------------------------
| This file will contain the settings specific to teh application.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|
| ------------------------------------------------------------------------------
*/

// Change this according to your OS. (I think that PHP resolves this for you
// ...though.)
$config['path_separator']    = '/';

// The generated code will apper in APPPATH/$config['output_base']
$config['output_base']       = 'crud_output/';

// You can change the suffix of generated code. Remember to change config.phpi
// ...when you deploy the generated code.
$config['suffix']            = 'php';

// Add your name and copyright details here. This will appear in generated code.
$config['programmer']        = 'Pradesh Chanderpaul';
$config['copyright'] 	     = "Copyright (c) 2006-2007 DataCraft Software";



#############################################
#Don't change anything below this line please
$config['theVersion'] = 'Code Crafter V 1.0 ';
$config['theCopyright'] =  "Copyright &copy; 2006-2007 DataCraft Software";

$config['now'] = date("D, F, d Y H:i");
$config['timestamp'] = date("Y-m-d H:i:s");

$config['unique'] = date("U");

?>
