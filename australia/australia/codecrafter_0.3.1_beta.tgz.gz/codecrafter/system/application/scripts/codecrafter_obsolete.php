<?

   // The CI database helper does not provide db meta data. so we are on our own.
   function GONElist_all_databases() {

      $all_dbs = array();

      $db_list = mysql_list_dbs(/* $link */);
      echo mysql_error();

      while ($row = mysql_fetch_object($db_list)) {
         $all_dbs[] = $row->Database;

      }

      return $all_dbs;
   }

   function GONElist_all_tables($table) {

      $all_tbls = array();

      $result = mysql_list_tables($table);

      while ($row = mysql_fetch_row($result)) {
//          print_r($row);
         $all_tbls[] = $row[0];
      }
      return $all_tbls;

   }

   function GONEdraw_db_tree($all_dbs) {

      $tree = '';
      $base_url = base_url();
      foreach  ( $all_dbs as $db ) {
         $tree .= "<DIV id='db_$db' style='width:100%;' onMouseOver=\"javascript:document.getElementById('db_$db').style.backgroundColor='#ffffff';\" onMouseOut=\"javascript:document.getElementById('db_$db').style.backgroundColor='#f9f9e8';\" onClick=\"javascript:select_db('$db'); \">\n<img src='$base_url" . "assets/db.gif' height='20' width='25'>$db<br></DIV>\n";

// /*         // Now build the children by listing all tables for the db;
//          $all_tables = list_all_tables($db);
//
//          foreach  ( $all_tables as $table ) {
//             // Build level 1 tree
//             $tree .= "<DIV id='tbl_$table' style='width:100%;' onMouseOver=\"javascript:document.getElementById('tbl_$table').style.backgroundColor='#ffffff';\" onMouseOut=\"javascript:document.getElementById('tbl_$table').style.backgroundColor='#f9f9e8';\" onClick=\"javascript:select_table('$db', '$table'); \">--><img src='$base_url" . "assets/table.gif' height='20' width='25'>$table<br></DIV>";
//
//          }         */
      }
      return $tree;
}

   function GONEdraw_table_tree($db) {

      $tree = '';

      // Now build the children by listing all tables for the db;
      $all_tables = list_all_tables($db);
      $base_url = base_url();
      foreach  ( $all_tables as $table ) {
         //Build level 1 tree
         $tree .= "<DIV id='tbl_$table' style='width:100%;' onMouseOver=\"javascript:document.getElementById('tbl_$table').style.backgroundColor='#f9f9e8';\" onMouseOut=\"javascript:document.getElementById('tbl_$table').style.backgroundColor='#ffffff';\" onClick=\"javascript:select_table('$db', '$table'); \">\n<img src='$base_url" . "assets/table.gif' height='20' width='25'>$table<br></DIV>\n";
      }

      return $tree;
   }

   function GONEget_field_data($table) {

      $sql = "SHOW COLUMNS FROM " . $table;

      $query = $this->db->query($sql);

      if ($query->num_rows() > 0) {
         foreach ($query->result() as $row) {
            print_r($row);
         }
      }


   }

?>