<tr <?= isset($rowstyle)?$rowstyle:''; ?>>
   <td style='border-bottom:1px black solid;border-left:1px black solid;'>
      <div style="float:left;">
         <input type='hidden' name='field_names[]' value='<?= $fieldname; ?>'><?= $fieldname; ?>
         <font color='gray' size=1>&nbsp;&nbsp;&nbsp;( <?= $fieldtype; ?> )</font>
      </div>
      <a class="bluebutton" href='#' onClick="javascript:toggleVis('details_<?= $fieldname; ?>');">Expand/Hide</a>
      <div id='details_<?= $fieldname; ?>'  style="display:none;background:#dfeaf6;border:1px dotted;">
<br><hr style="border:1px green dashed;">
         <div id='type_<?= $fieldname; ?>'>
            <label for='field_type_<?= $fieldname; ?>'>Type :</label>
            <?= $field_type_dropdown; ?><br />
         </div>

         <div id='size_<?= $fieldname; ?>'>
            <label for='field_size_<?= $fieldname; ?>'>Size:</label>
            <input type='input' name='field_size_<?= $fieldname; ?>' value='<?= $field_size; ?>' size=10><br />
         </div>

         <div id='optionlist_<?= $fieldname; ?>'>
            <label for='optionlist_<?= $fieldname; ?>'>Options/Lists :</label>
            <input type='input' name='field_optionlist_<?= $fieldname; ?>' value='<?= $field_optionlist; ?>' size=20><br />
         </div>

         <div id='label_<?= $fieldname; ?>'>
            <label for='label_<?= $fieldname; ?>'>Label :</label>
            <input type='input' name='field_label_<?= $fieldname; ?>' value='<?= $fieldname; ?>' size=20><br />
         </div>

         <div id='relations_<?= $fieldname; ?>'>
            <label for='relations_<?= $fieldname; ?>'>Relations :</label>
            <input type='checkbox' name='lookup_<?= $fieldname; ?>' value='more' onClick='javascript:ShowLookup("lookup_<?= $fieldname; ?>");'>
            <div id='lookup_<?= $fieldname; ?>' style='display:none;'>

   <!--            <select id='lookup_type_<?= $fieldname; ?>' name=''>
                  <option>Select relation type </option>
                  <option value='one_to_one'>One:One</option>
                  <option value='one_to_many'>One:Many</option>
               </select>-->

               <select id='lookup_tbl_<?= $fieldname; ?>' name='lookup_tbl_<?= $fieldname; ?>' onChange="javascript:FieldNameDropDown('lookup_tbl_<?= $fieldname; ?>','lookup_fld_<?= $fieldname; ?>', 'display_fld_<?= $fieldname; ?>')">
                  <option>Select lookup table</option>
      <?          foreach ($tablelist as $table_name) { ?>
                     <option value='<?= $table_name; ?>'><?= $table_name; ?></option>
      <?          } ?>
               </select>

               <select id='lookup_fld_<?= $fieldname; ?>' name='lookup_fld_<?= $fieldname; ?>'>
                  <option>Select lookup field</option>
               </select>

               <select id='display_fld_<?= $fieldname; ?>' name='display_fld_<?= $fieldname; ?>'>
                  <option>Select display field</option>
               </select>

            </div>

            <div id='fieldnames' style="display:none;">
            </div>

            <br />
         </div>
      </div>
   </td>

</tr>