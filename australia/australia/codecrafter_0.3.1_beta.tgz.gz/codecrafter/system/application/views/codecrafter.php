<html>
<head>
<title>Welcome to the Code Crafter V0.3</title>

<style type="text/css">

body { 
 background-color: #fff; 
 margin: 20px; 
 font-family: Lucida Grande, Verdana, Sans-serif;
 font-size: 13px;
 color: #4F5155;
}

a {
 color: #003399;
 background-color: transparent;
 font-weight: normal;
}

h1 {
 color: #444;
 background-color: transparent;
 border-bottom: 1px solid #D0D0D0;
 font-size: 16px;
 font-weight: bold;
 margin: 20px 0 2px 0;
 padding: 5px 0 6px 0;
}

code {
 font-family: Monaco, Verdana, Sans-serif;
 font-size: 12px;
 background-color: #f9f9f9;
 border: 1px solid #D0D0D0;
 color: #002166;
 display: block;
 margin: 14px 0 14px 0;
 padding: 12px 10px 12px 10px;
}

</style>
<STYLE>
.result_item {
   border-bottom: 1px solid #d2d7c6;
   z-index:300;
   width: 210px;
   /* max-width: 230px; */
   padding:15px 5px 15px 10px;
   background-color: #f9f9e8
}

.project_description {
 color:#333333;
 font-weight:normal; 
 /* font-weight:bold; */ }  

.project_ref  { 
 font-size:12px; color:#333333;
 font-weight:bold;
 padding:0; 
 margin:0; 
 line-height:1em; }

.project_title  { 
 font-size:12px; color:#333333;
 font-weight:bold;
 padding:0; 
 margin:0; 
 line-height:1em; }

select input textarea{
        BORDER-RIGHT: 1px solid #9CC4E4;
        BORDER-TOP: 1px solid #94BADD;
        FONT-WEIGHT: normal;
        FONT-SIZE: 11px;
        BORDER-LEFT: 1px solid #9CC4E4;
        COLOR: #333333;
        BORDER-BOTTOM: 1px solid #A3CCEB;
        font-family: Verdana, Arial, Helvetica, sans-serif;
        padding-right: 2px;
        padding-left: 2px;
        vertical-align: top;
        height: 20px;
        background-repeat: repeat-x;
}


</STYLE>

<SCRIPT>

function ToggleAdvancedDetails( form ) {

   var adv_option = form.flag_advanced.checked;
   
   if ( adv_option == false ) {
      try {
               document.getElementById('advanced_options').style.display = "none";
      }
      catch (e) {
         ;
      }
   }
   else {
      try {
               document.getElementById('advanced_options').style.display = "block";
      }
      catch (e) {
         ;
      }
   }

}

function select_table(db_name, db_table) {
   
   // Populate the form on behalf of the user;
   document.getElementById('d_name').value = db_name;
   document.getElementById('d_table').value = db_table;
   
   // Get the other database values from the form
   var db_host    = document.getElementById('d_host').value;
   var db_user     = document.getElementById('d_user').value;
   var db_userpass = document.getElementById('d_userpass').value;

   var parms='dummy=nothing';
   parms += ((db_name     == undefined) ? '' : '&d_name='+db_name);
   parms += ((db_user     == undefined) ? '' : '&d_user='+db_user);
   parms += ((db_userpass == undefined) ? '' : '&d_userpass='+db_userpass);
   parms += ((db_host     == undefined) ? '' : '&d_host='+db_host);
   parms += ((db_table    == undefined) ? '' : '&d_table='+db_table);
   
var url = '<?= site_url('codecrafter/fetchtabledef/'); ?>';

var target = 'tabledefs';
var myAjax = new Ajax.Updater(target, url, {method: 'post', parameters: parms, onComplete: showTablePanel});

}

function select_db(db_name) {
   
   // Populate the form on behalf of the user;
   document.getElementById('d_name').value = db_name;
//    document.getElementById('d_table').value = db_table;
   
   // Get the other database values from the form
   var db_host    = document.getElementById('d_host').value;
   var db_user     = document.getElementById('d_user').value;
   var db_userpass = document.getElementById('d_userpass').value;

   var parms='dummy=nothing';
   parms += ((db_name     == undefined) ? '' : '&d_name='+db_name);
   parms += ((db_user     == undefined) ? '' : '&d_user='+db_user);
   parms += ((db_userpass == undefined) ? '' : '&d_userpass='+db_userpass);
   parms += ((db_host     == undefined) ? '' : '&d_host='+db_host);
//    parms += ((db_table    == undefined) ? '' : '&d_table='+db_table);
   
var url = '<?= site_url('codecrafter/fetchtablelist/'); ?>';

var target = 'tablevalues';
var myAjax = new Ajax.Updater(target, url, {method: 'post', parameters: parms, onComplete: showTableListing});

}




</SCRIPT>

<script type="text/javascript" langage="javascript" src="<?= base_url().'assets/prototype.js'; ?>" ></script>

<script type="text/javascript" langage="javascript">


function ProgressFunction(msg,leng)
{
   if(leng) window.status=leng;
   
}

function ErrFunction(msg,code)
{
   alert(code+'\r\n'+msg);
}

function FetchDBValues() {


   // get the databse values from the form.
      
   var db_host    = document.getElementById('d_host').value;
   var db_user     = document.getElementById('d_user').value;
   var db_userpass = document.getElementById('d_userpass').value;
   var db_name     = document.getElementById('d_name').value;

   var parms='dummy=nothing';
   parms += ((db_name     == undefined) ? '' : '&d_name='+db_name);
   parms += ((db_user     == undefined) ? '' : '&d_user='+db_user);
   parms += ((db_userpass == undefined) ? '' : '&d_userpass='+db_userpass);
   parms += ((db_host     == undefined) ? '' : '&d_host='+db_host);
   
   var url = '/codecrafter/codecrafter/fetchdbs/'; 
   var target = 'dbvalues';
   var myAjax = new Ajax.Updater(target, url, {method: 'post', parameters: parms, onComplete: showDBPanel});
   
   return false;   

}

function showDBPanel() {
   document.getElementById('dbdata').style.display = 'block';
}

function showTablePanel() {
   document.getElementById('tbldata').style.display = 'block';
}

function showTableListing() {
   document.getElementById('tabledata').style.display = 'block';
}

</SCRIPT>


</head>
<body>

<h1>Welcome to Code Crafter!</h1>

<form NAME='ccoptions' method="post" action="<?= site_url('codecrafter/generate/');?>">


<TABLE>
<TR valign='top'>
  <TD WIDTH='30%'>
         <DIV style="border:3px solid #d2d7c6;width:300px;">
         <table  class="tableWidget"  width="100%"  border="0" cellspacing="0" cellpadding="0">
         <THEAD>
            <TR BGCOLOR='silver'>
               <td  class="tableWidget_headerCell" style="background-color:#f2f3ee;" VALIGN="MIDDLE" ALIGN="CENTER">
                  DATABASE INFORMATION
               </td>
            </TR>
         </THEAD>

         <tbody style="height: 300px;background-color:#ffffff;" class="scrollingContent">
            <TR style="background-color:#f9f9e8;valign:top;">
               <TD valign='top'>
                  <DIV id="projectactivities" style="display:block;">

                     <table class="forum" cellpadding="2" cellspacing="5" width="300">
                        <tr>
                           <td width='40%'>MySQL server</td>
                           <td><input id="d_host" name="d_host" class="text" value="<?= $db_host; ?>" type="text">
                        </td></tr>
                        <tr>
                           <td>Database username</td>
                           <td><input id="d_user" name="d_user" class="text" value="<?= $db_user; ?>" type="text">
                        </td></tr>
                        <tr>
                           <td>Database password</td>
                           <td><input id="d_userpass" name="d_userpass" class="text" value="<?= $db_password; ?>" type="password">
                        </td></tr>
                        <tr>
                           <td width='40%'>Database name</td>
                           <td><input id="d_name" name="d_name" class="text" value="" type="text">
                        </td></tr>
                        <tr>
                           <td>Advanced</td>
                           <td><input id="flag_advanced" name="flag_advanced" class="text" value="advanced" type="checkbox" onChange="ToggleAdvancedDetails(this.form);"></td>
                        </tr>
                     </tbody></table>
                     
                     <DIV ID='advanced_options' STYLE='display:none;'>
                     <table class="forum" cellpadding="2" cellspacing="5" width="300">
                        <tbody>
                        <tr>
                           <td colspan="2" style="margin: 0pt; padding: 0pt; background-color: rgb(221, 221, 187);"><p style="font-size: 1px;">&nbsp;</p></td>
                        </tr>
                        <tr>
                           <th colspan="2">Advanced Options<BR></th>
                        </tr>
                     
                        <tr width='40%'>
                           <td>Database table<BR>
                           </td>
                           <td align='center'>
                              <input id="d_table" name="d_table" class="text" value="" type="text"><BR>
                              OR<BR>
                              <input id="fetch_tables" name="fetch_tables" value="Fetch tables for me" type="submit" onClick="javascript:FetchDBValues();return false;">
                           </td>
                        </tr>
                        <tr>
                           <td>Overwrite Protection</td>
                           <td><input name="flag_clobber" class="text" value="clobber" type="checkbox" onChange="ToggleAdvancedDetails(this.form);">&nbsp;Overwrite Directory Structure</td>
                        </tr>
                        <tr>
                           <td>Output To:</td>
                           <td><input name="target_disk" class="text" value="write_to_disk" type="checkbox" checked>&nbsp;Disk&nbsp;&nbsp;&nbsp;
                               <input name="target_screen" class="text" value="write_to_screen" type="checkbox">&nbsp;Screen
                              </td>
                        </tr>
                        <tr>
                           <td>Navigation:</td>
                           <td><input name="build_navigator" class="text" value="build_navigator" type="checkbox" checked>&nbsp;Create Navigator&nbsp;&nbsp;&nbsp;
                              </td>
                        </tr>

                        <tr>
                           <td colspan="2" style="margin: 0pt; padding: 0pt; background-color: rgb(221, 221, 187);"><p style="font-size: 1px;">&nbsp;</p></td>
                        </tr>
                        <tr>
                           <td colspan="2"><p class="smaller" style="margin: 3px; padding: 0pt;">
                           <UL>
                              <LI>Enter a database name if you want code generated for a specific database.
                                 Otherwise Code Crafter will allow you choose from existing databases.
                              <LI>Enter a table name if you want code generated for a specific table.
                                 Otherwise Code Crafter will generate code for all tables in the specified database.
                              <LI>By default, CodeCrafter will not overwrite existing directories in its output directory. Click the Overwrite option if you can afford to lose your existing files.
                           <BR>
                           </td>
                        </tr>
                        <tr>
                           <td colspan="2" style="margin: 0pt; padding: 0pt; background-color: rgb(221, 221, 187);"><p style="font-size: 1px;">&nbsp;</p></td>
                        </tr>
                     </tbody></table>
                     </DIV>

                  </DIV>

               </TD>
            </tr>
         </TBODY>
         </table>
         </DIV>  
  </TD>
  <TD WIDTH='70%'>
      <TABLE WIDTH='100%'>
      <TR VALIGN='top'>
         <TD WIDTH='50%' VALIGN='top'>
            <DIV ID='dbdata' style="border:3px solid #d2d7c6;display:none;width:300px;">
            <table  class="tableWidget"  width="100%"  border="0" cellspacing="0" cellpadding="0">
            <THEAD>
               <TR BGCOLOR='silver'>
                  <td  class="tableWidget_headerCell" style="background-color:#f2f3ee;" VALIGN="MIDDLE" ALIGN="CENTER">
                     DATABASE LISTING
                  </td>
               </TR>
            </THEAD>
            <tbody style="background-color:#ffffff;" class="scrollingContent">
               <TR style="background-color:#f9f9e8;valign:top;">
                  <TD valign='top'>
                     <DIV id="dbvalues" style="display:block;overflow:auto;-color:blue;height:220px;">
                     the database listing goes here.
                     </DIV>
            
                  </TD>
               </tr>
            </TBODY>
            </table>
            </DIV>
         </TD>
         <TD WIDTH='50%'>
            <DIV ID='tabledata' style="border:3px solid #d2d7c6;display:none;width:300px;">
            <table  class="tableWidget"  width="100%"  border="0" cellspacing="0" cellpadding="0">
            <THEAD>
               <TR BGCOLOR='silver'>
                  <td  class="tableWidget_headerCell" style="background-color:#f2f3ee;" VALIGN="MIDDLE" ALIGN="CENTER">
                     TABLE LISTING
                  </td>
               </TR>
            </THEAD>
            <tbody style="background-color:#ffffff;" class="scrollingContent">
               <TR style="background-color:#f9f9e8;valign:top;">
                  <TD valign='top'>
                     <DIV id="tablevalues" style="display:block;overflow:auto;-color:blue;height:220px;">
                     the database table listing goes here.
                     </DIV>
            
                  </TD>
               </tr>
            </TBODY>
            </table>
            </DIV>
   
         </TD>
      </TR>
      <TR>
         <TD WIDTH='100%' VALIGN='top' colspan=2>
            <DIV ID='tbldata' style="border:3px solid #d2d7c6;display:none;width:620px;overflow:auto;">
            <table  class="tableWidget"  width="100%"  border="0" cellspacing="0" cellpadding="0">
            <THEAD>
               <TR BGCOLOR='silver'>
                  <td  class="tableWidget_headerCell" style="background-color:#f2f3ee;" VALIGN="MIDDLE" ALIGN="CENTER">
                     TABLE FIELD DETAILS <FONT COLOR='RED'>CODE GENERATION ONE TABLE AT A TIME</A>
                  </td>
               </TR>
            </THEAD>
            <tbody style="background-color:#ffffff;" class="scrollingContent">
               <TR style="background-color:#f9f9e8;valign:top;">
                  <TD valign='top'>
                     <DIV id="tabledefs" style="display:block;overflow:auto;-color:blue;height:300px;">
                     the table definition goes here.
                     </DIV>
                  </TD>
               </tr>
            </TBODY>
            </table>
            </DIV>
   
         </TD>
      </TR>
      </TABLE>
  </TD>
</TR>
</TABLE>


<table class="forum" cellpadding="2" cellspacing="5" width="500">
	<tr>

		<td colspan="2" style="text-align: center;">
        <input name="generate" value="Go ahead. Make my code" type="submit"></td>
	</tr>

	<tr>
		<td colspan="2" style="margin: 0pt; padding: 0pt; background-color: rgb(221, 221, 187);"><p style="font-size: 1px;">&nbsp;</p></td>
	</tr>
	<tr>
		<td colspan="2"><p class="smaller" style="margin: 3px; padding: 0pt;">
      Code Crafter will create all the necessary files for the database table you have selected.</P>
      <font size=2 color='red'> Existing files may be overwritten.<BR>
      </td>
	</tr>
	<tr>
		<td colspan="2" style="margin: 0pt; padding: 0pt; background-color: rgb(221, 221, 187);"><p style="font-size: 1px;">&nbsp;</p></td>
	</tr>
</tbody></table>
       


<p><br />Page rendered in {elapsed_time} seconds</p>

</body>
</html>
